import { RepairSidebar } from "@/components/layout/sidebar/repair-sidebar"
import { PageLayout } from "@/components/layout/page-layout"
import { ServiceCard } from "@/components/services/service-card"
import { Badge } from "@/components/ui/badge"
import { TestimonialsSection } from "@/components/testimonials/testimonials-section"

const repairServices = [
  {
    id: "1",
    title: "Screen Replacement",
    description: "Professional screen repair for all smartphone models with genuine parts and warranty.",
    price: "From $89",
    duration: "30-60 mins",
    image: "/smartphone-screen-repair-technician-working.png",
    slug: "screen-replacement",
  },
  {
    id: "2",
    title: "Battery Replacement",
    description: "Restore your phone's battery life with high-quality replacement batteries.",
    price: "From $59",
    duration: "20-30 mins",
    image: "/phone-battery-replacement-service.png",
    slug: "battery-replacement",
  },
  {
    id: "3",
    title: "Water Damage Repair",
    description: "Emergency water damage recovery with specialized drying and component repair.",
    price: "From $129",
    duration: "2-4 hours",
    image: "/water-damaged-phone-repair.png",
    slug: "water-damage",
  },
  {
    id: "4",
    title: "Software Troubleshooting",
    description: "Fix software issues, remove viruses, and optimize your device performance.",
    price: "From $39",
    duration: "15-45 mins",
    image: "/phone-software-repair-diagnostic.png",
    slug: "software-repair",
  },
  {
    id: "5",
    title: "Camera Repair",
    description: "Professional camera lens and sensor repair for crystal clear photos.",
    price: "From $79",
    duration: "45-90 mins",
    image: "/smartphone-camera-lens-repair.png",
    slug: "camera-repair",
  },
  {
    id: "6",
    title: "Charging Port Fix",
    description: "Repair loose or damaged charging ports to restore proper charging.",
    price: "From $69",
    duration: "30-45 mins",
    image: "/phone-charging-port-repair.png",
    slug: "charging-port",
  },
]

const serviceCategories = [
  { title: "Screen Repairs", slug: "screen-repairs" },
  { title: "Battery Services", slug: "battery-services" },
  { title: "Water Damage", slug: "water-damage" },
  { title: "Software Issues", slug: "software-issues" },
  { title: "Hardware Repairs", slug: "hardware-repairs" },
  { title: "Diagnostics", slug: "diagnostics" },
]

export default async function Home() {
  const [featuredService, ...otherServices] = repairServices

  return (
    <PageLayout>
      <div className="contents md:grid md:grid-cols-12 md:gap-sides">
        <RepairSidebar services={serviceCategories} />
        <div className="flex relative flex-col grid-cols-2 col-span-8 w-full md:grid">
          <div className="fixed top-0 left-0 z-10 w-full pointer-events-none base-grid py-sides">
            <div className="col-span-8 col-start-5">
              <div className="hidden px-6 lg:block">
                <Badge variant="outline" className="bg-accent/10 text-accent border-accent/20">
                  expert repairs
                </Badge>
              </div>
            </div>
          </div>

          <ServiceCard className="col-span-2" service={featuredService} featured />

          {otherServices.map((service, index) => (
            <ServiceCard className="col-span-1" key={service.id} service={service} />
          ))}
        </div>
      </div>

      <div className="container mx-auto px-sides">
        <TestimonialsSection limit={4} compact />
      </div>
    </PageLayout>
  )
}
