import type { Metadata } from "next"
import { notFound } from "next/navigation"
import { PageLayout } from "@/components/layout/page-layout"
import { BookingForm } from "@/components/booking/booking-form"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
  BreadcrumbPage,
} from "@/components/ui/breadcrumb"
import Link from "next/link"

const serviceData = {
  "screen-replacement": {
    id: "1",
    title: "Screen Replacement",
    description: "Professional screen repair for all smartphone models with genuine parts and warranty.",
    price: "From $89",
    duration: "30-60 mins",
    image: "/smartphone-screen-repair-technician-working.png",
    category: "Hardware Repair",
  },
  "battery-replacement": {
    id: "2",
    title: "Battery Replacement",
    description: "Restore your phone's battery life with high-quality replacement batteries.",
    price: "From $59",
    duration: "20-30 mins",
    image: "/phone-battery-replacement-service.png",
    category: "Hardware Repair",
  },
  "water-damage": {
    id: "3",
    title: "Water Damage Repair",
    description: "Emergency water damage recovery with specialized drying and component repair.",
    price: "From $129",
    duration: "2-4 hours",
    image: "/water-damaged-phone-repair.png",
    category: "Emergency Repair",
  },
  "software-repair": {
    id: "4",
    title: "Software Troubleshooting",
    description: "Fix software issues, remove viruses, and optimize your device performance.",
    price: "From $39",
    duration: "15-45 mins",
    image: "/phone-software-repair-diagnostic.png",
    category: "Software Service",
  },
  "camera-repair": {
    id: "5",
    title: "Camera Repair",
    description: "Professional camera lens and sensor repair for crystal clear photos.",
    price: "From $79",
    duration: "45-90 mins",
    image: "/smartphone-camera-lens-repair.png",
    category: "Hardware Repair",
  },
  "charging-port": {
    id: "6",
    title: "Charging Port Fix",
    description: "Repair loose or damaged charging ports to restore proper charging.",
    price: "From $69",
    duration: "30-45 mins",
    image: "/phone-charging-port-repair.png",
    category: "Hardware Repair",
  },
}

export async function generateStaticParams() {
  return Object.keys(serviceData).map((service) => ({
    service,
  }))
}

export async function generateMetadata({ params }: { params: Promise<{ service: string }> }): Promise<Metadata> {
  const { service } = await params
  const serviceInfo = serviceData[service as keyof typeof serviceData]

  if (!serviceInfo) {
    return {
      title: "Service Not Found",
    }
  }

  return {
    title: `Book ${serviceInfo.title} | PhoneFix Pro`,
    description: `Schedule your ${serviceInfo.title.toLowerCase()} appointment with our expert technicians.`,
  }
}

export default async function BookServicePage({ params }: { params: Promise<{ service: string }> }) {
  const { service } = await params
  const serviceInfo = serviceData[service as keyof typeof serviceData]

  if (!serviceInfo) {
    notFound()
  }

  return (
    <PageLayout>
      <div className="container mx-auto px-sides py-8 max-w-4xl">
        <Breadcrumb className="mb-8">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link href="/services" prefetch>
                  Services
                </Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link href={`/services/${service}`} prefetch>
                  {serviceInfo.title}
                </Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>Book Appointment</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Service Summary */}
          <div className="lg:col-span-1">
            <div className="bg-card rounded-lg border p-6 sticky top-8">
              <div className="aspect-video mb-4 overflow-hidden rounded-lg">
                <img
                  src={serviceInfo.image || "/placeholder.svg"}
                  alt={serviceInfo.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <h2 className="text-xl font-semibold mb-2">{serviceInfo.title}</h2>
              <p className="text-muted-foreground text-sm mb-4">{serviceInfo.description}</p>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Duration:</span>
                  <span className="text-sm font-medium">{serviceInfo.duration}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Price:</span>
                  <span className="text-sm font-medium">{serviceInfo.price}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Category:</span>
                  <span className="text-sm font-medium">{serviceInfo.category}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Booking Form */}
          <div className="lg:col-span-2">
            <div className="bg-card rounded-lg border p-6">
              <h1 className="text-2xl font-bold mb-6">Book Your Appointment</h1>
              <BookingForm service={serviceInfo} />
            </div>
          </div>
        </div>
      </div>
    </PageLayout>
  )
}
